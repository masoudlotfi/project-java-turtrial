package com.omidanalyzer.test;

/**
 * Created by masoudLofti on 7/11/17.
 */
public interface BrainInterface {

    String doTest();

}